//
//  main.m
//  Factorial
//
//  Created by FBI on 16/7/27.
//  Copyright © 2016年 君陌. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
