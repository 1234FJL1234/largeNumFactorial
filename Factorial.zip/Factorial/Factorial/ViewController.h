//
//  ViewController.h
//  JM_Autolayout
//
//  Created by FBI on 16/4/8.
//  Copyright © 2016年 君陌. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

